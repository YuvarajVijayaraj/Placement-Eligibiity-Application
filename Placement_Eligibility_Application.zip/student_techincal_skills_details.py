import random

class TechnicalSkills:
    def __init__(self, student_db_cursor,  student_db):
        self.student_db = student_db
        self.cursor = student_db_cursor

    def create_table(self):
        self.cursor.execute("""
        CREATE TABLE IF NOT EXISTS programming (
            programming_id INT AUTO_INCREMENT PRIMARY KEY,
            student_id INT,
            language VARCHAR(50),
            problems_solved INT,
            assessments_completed INT,
            mini_projects INT,
            certifications_earned INT,
            latest_project_score INT,
            FOREIGN KEY (student_id) REFERENCES students(student_id)
        )
        """)
        self.student_db.commit()
        print("✅ 'programming' table created")

    def insert_data(self, student_ids):
        languages = ["Python", "SQL", "Java", "C++", "C"]
        for student_id in student_ids:
            num_languages = random.randint(2, 3)
            language_list = random.sample(languages, num_languages)
            language = ", ".join(language_list)
            problems_solved = random.randint(10, 100)
            assessments_completed = random.randint(1, 10)
            mini_projects = random.randint(0, 5)
            certifications_earned = random.randint(0, 3)
            latest_project_score = random.randint(50, 100)

            self.cursor.execute("""
            INSERT INTO programming (student_id, language, problems_solved, assessments_completed,
            mini_projects, certifications_earned, latest_project_score)
            VALUES (%s, %s, %s, %s, %s, %s, %s)
            """, (
                student_id, 
                language, 
                problems_solved, 
                assessments_completed, 
                mini_projects, 
                certifications_earned, 
                latest_project_score
            ))

        self.student_db.commit()
        print(f"✅ Inserted technical skills for {len(student_ids)} students")
