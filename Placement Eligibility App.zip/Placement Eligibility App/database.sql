CREATE DATABASE student_database;
