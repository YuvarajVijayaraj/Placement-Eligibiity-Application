import mysql.connector
from student_personal_details import StudentInfo
from student_techincal_skills_details import TechnicalSkills
from student_soft_skills_details import SoftSkill
from student_placement_details import PlacementInfo

def connect_mysql():
    connection = mysql.connector.connect(
        host="localhost",
        user="root",
        password="Saiyuvi17&",
        database="student_database"
    )
    return connection

def main():
    print("$$ Connecting to MySQL $$")
    student_db = connect_mysql()
    student_db_cursor = student_db.cursor()
    print("✅ Connected to MySQL")

    # Creating instances for each entry
    student_info = StudentInfo(student_db_cursor, student_db)
    techincalskill_info = TechnicalSkills(student_db_cursor, student_db)
    softskill_info = SoftSkill(student_db_cursor, student_db)
    placement_info = PlacementInfo(student_db_cursor, student_db)

    print("$$ Creating tables $$")
    # Creating tables in SQL
    student_info.create_table()
    techincalskill_info.create_table()
    softskill_info.create_table()
    placement_info.create_table()
    print("✅ All tables created successfully")

    # Inserting data into SQL
    students_count = 20
    print(f"$$ Inserting data for {students_count} students $$")
    student_ids = student_info.insert_data(students_count)
    print("✅ Student personal data inserted")

    techincalskill_info.insert_data(student_ids)
    print("✅ Technical skills data inserted")

    softskill_info.insert_data(student_ids)
    print("✅ Soft skills data inserted")

    placement_info.insert_data(student_ids)
    print("✅ Placement data inserted")

    # Closing connections
    student_db_cursor.close()
    student_db.close()
    print("✅ All entries inserted and connection closed")

main()