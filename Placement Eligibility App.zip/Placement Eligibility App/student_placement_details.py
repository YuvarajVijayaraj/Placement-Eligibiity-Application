import random
from faker import Faker

class PlacementInfo:
    def __init__(self, student_db_cursor, student_db):
        self.student_db = student_db
        self.cursor = student_db_cursor
        self.fake = Faker()

    def create_table(self):
        self.cursor.execute("DROP TABLE IF EXISTS placements")
        self.cursor.execute("""
        CREATE TABLE placements (
            placement_id INT AUTO_INCREMENT PRIMARY KEY,
            student_id INT,
            mock_interview_score INT,
            internships_completed INT,
            placement_status VARCHAR(20),
            company_name VARCHAR(100) DEFAULT 'Not Placed',
            placement_package FLOAT DEFAULT 0,
            interview_rounds_cleared INT,
            placement_date DATE,
            FOREIGN KEY (student_id) REFERENCES students(student_id)
        )
        """)
        self.student_db.commit()
        print("✅ 'placements' table created")

    def insert_data(self, student_ids):
        statuses = ["Placed", "Ready", "Not Ready"]
        for student_id in student_ids:
            status = random.choice(statuses)
            company = self.fake.company() if status == "Placed" else "Not Placed"
            package = round(random.uniform(4.0, 12.0), 2) if status == "Placed" else 0
            date = self.fake.date_this_year() if status == "Placed" else None
            print(f"Student: {student_id} | Status: {status} | Company: {company} | Package: {package}")

            self.cursor.execute("""
            INSERT INTO placements (student_id, mock_interview_score, internships_completed,
            placement_status, company_name, placement_package, interview_rounds_cleared, placement_date)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
            """, (
                student_id,
                random.randint(50, 100),
                random.randint(0, 3),
                status,
                company,
                package,
                random.randint(1, 5),
                date
            ))
        self.student_db.commit()
        print(f"✅ Inserted placement details for {len(student_ids)} students")
