import streamlit as st
import mysql.connector
import pandas as pd

# MySQL connection
def connect_mysql():
    return mysql.connector.connect(
        host="localhost",
        user="root",
        password="Saiyuvi17&",
        database="student_database"
    )

st.title("🎓 Student Placement Eligibility Dashboard")

# Filters
st.sidebar.header("📋 Apply Filters")

min_soft_skill = st.sidebar.slider("Minimum Soft Skills Avg Score", 0, 100, 75)
min_problems = st.sidebar.number_input("Minimum Problems Solved", 0, 1000, 50)
min_assessments = st.sidebar.number_input("Minimum Assessments Completed", 0, 100, 5)
min_projects = st.sidebar.number_input("Minimum Mini Projects", 0, 50, 2)
min_mock_score = st.sidebar.number_input("Minimum Mock Interview Score", 0, 100, 70)
placement_status = st.sidebar.selectbox("Placement Status", ["Placed", "Not Ready", "Ready", "All"])

if st.sidebar.button("Show Eligible Students"):
    db = connect_mysql()
    
    # Build query dynamically
    base_query = """
        SELECT 
            s.student_id,
            s.name,
            p.language,
            p.problems_solved,
            p.assessments_completed,
            p.mini_projects,
            AVG(ss.communication) AS communication,
            AVG(ss.teamwork) AS teamwork,
            AVG(ss.presentation) AS presentation,
            AVG(ss.leadership) AS leadership,
            AVG(ss.critical_thinking) AS critical_thinking,
            AVG(ss.interpersonal_skills) AS interpersonal_skills,
            AVG(
                (ss.communication + ss.teamwork + ss.presentation + ss.leadership + 
                ss.critical_thinking + ss.interpersonal_skills)/6
            ) AS avg_soft_skills,
            pl.mock_interview_score,
            pl.placement_status
        FROM students s
        JOIN programming p ON s.student_id = p.student_id
        JOIN soft_skills ss ON s.student_id = ss.student_id
        JOIN placements pl ON s.student_id = pl.student_id
        WHERE p.problems_solved >= %s
          AND p.assessments_completed >= %s
          AND p.mini_projects >= %s
          AND pl.mock_interview_score >= %s
    """
    params = [min_problems, min_assessments, min_projects, min_mock_score]

    # Add placement_status filter if not "All"
    if placement_status != "All":
        base_query += " AND pl.placement_status = %s"
        params.append(placement_status)

    base_query += """
        GROUP BY 
            s.student_id, s.name, p.language, p.problems_solved, 
            p.assessments_completed, p.mini_projects, 
            pl.mock_interview_score, pl.placement_status
        HAVING avg_soft_skills >= %s
    """
    params.append(min_soft_skill)

    # Execute and display
    df = pd.read_sql(base_query, db, params=params)
    st.subheader("📋 Eligible Students")
    st.dataframe(df)
    db.close()

# Placement Insights
st.subheader("📊 Placement Insights")

options = {
    "1. Average programming performance per batch":
        """
        SELECT course_batch, AVG(problems_solved) AS avg_problems
        FROM students s JOIN programming p ON s.student_id = p.student_id
        GROUP BY course_batch
        """,

    "2. Top 5 students ready for placement":
        """
        SELECT s.name, pl.placement_status, pl.mock_interview_score
        FROM students s JOIN placements pl ON s.student_id = pl.student_id
        WHERE pl.placement_status = 'Ready'
        ORDER BY pl.mock_interview_score DESC
        LIMIT 5
        """,

    "3. Distribution of soft skills scores":
        """
        SELECT 
            (communication + teamwork + presentation + leadership + 
            critical_thinking + interpersonal_skills)/6 AS avg_soft_score
        FROM soft_skills
        """,

    "4. Placement status count":
        """
        SELECT placement_status, COUNT(*) AS count
        FROM placements
        GROUP BY placement_status
        """,

    "5. Top 5 students with most problems solved":
        """
        SELECT s.name, p.problems_solved
        FROM students s JOIN programming p ON s.student_id = p.student_id
        ORDER BY p.problems_solved DESC
        LIMIT 5
        """,

    "6. Students with good critical thinking":
        """
        SELECT s.name, ss.critical_thinking
        FROM students s 
        JOIN soft_skills ss ON s.student_id = ss.student_id
        WHERE ss.critical_thinking >= 85
        ORDER BY ss.critical_thinking DESC
        """,

    "7. Top 5 Students having good communication skills":
        """
        SELECT s.name, ss.communication
        FROM students s 
        JOIN soft_skills ss ON s.student_id = ss.student_id
        ORDER BY ss.communication DESC
        LIMIT 5
        """,

    "8. Graduation year-wise placement count":
        """
        SELECT graduation_year, COUNT(pl.placement_id) AS placed_count
        FROM students s JOIN placements pl ON s.student_id = pl.student_id
        WHERE placement_status = 'Placed'
        GROUP BY graduation_year
        """,

    "9. Top placed students by package":
        """
        SELECT s.name, pl.company_name, pl.placement_package
        FROM students s JOIN placements pl ON s.student_id = pl.student_id
        WHERE placement_status = 'Placed'
        ORDER BY placement_package DESC
        LIMIT 5
        """,

    "10. Students with certification and placement":
        """
        SELECT s.name, p.certifications_earned, pl.company_name
        FROM students s
        JOIN programming p ON s.student_id = p.student_id
        JOIN placements pl ON s.student_id = pl.student_id
        WHERE p.certifications_earned > 0 AND pl.placement_status = 'Placed'
        """
}


selected_query = st.selectbox("Select an insight to view", list(options.keys()))
if selected_query:
    db = connect_mysql()
    df = pd.read_sql(options[selected_query], db)
    st.dataframe(df)
    db.close()
