import random
from faker import Faker

class StudentInfo:
    def __init__(self, student_db_cursor, student_db):
        self.student_db = student_db
        self.cursor = student_db_cursor
        self.fake = Faker('en_IN')

    def create_table(self):
        self.cursor.execute("""
        CREATE TABLE IF NOT EXISTS students (
            student_id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(100),
            age INT,
            gender VARCHAR(10),
            email VARCHAR(100),
            phone VARCHAR(15),
            enrollment_year INT,
            course_batch VARCHAR(50),
            city VARCHAR(50),
            graduation_year INT
        )
        """)
        self.student_db.commit()
        print("✅ 'students' table created")

    def insert_data(self, n):
        student_ids = []

        tn_cities = ["Chennai", "Tanjore", "Salem", "Coimbatore", "Madurai", "Thiruvannamalai", "Trichy", "Vellore", "Neiveli"]
        tn_names = ["Yuvaraj", "Raghavan", "Rajeshwari", "Umadevi", "Vijayaraj", "Padmapriya", "Venugopal", "Ravi kumar", "Thamarai Selvi"]
        city_index = 0
        name_index = 0

        random.shuffle(tn_names)

        for _ in range(n):
            if name_index < 5:
                name = tn_names[name_index]
                name_index += 1
            else:
                name = self.fake.name()

            age = random.randint(18, 25)
            gender = random.choice(["Male", "Female"])

            email_username = name.lower().replace(" ", ".")
            email = f"{email_username}@gmail.com"
            phone = f"+91-{random.randint(7000000000, 9999999999)}"

            enrollment_year = random.randint(2023, 2025)
            course_batch = f"Batch-{random.randint(1, 5)}"
            graduation_year = enrollment_year + 1

            if city_index < 5:
                city = random.choice(tn_cities)
                city_index += 1
            else:
                city = self.fake.city()

            self.cursor.execute("""
            INSERT INTO students (name, age, gender, email, phone, enrollment_year, course_batch, city, graduation_year)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
            """, (
                name, 
                age, 
                gender, 
                email, 
                phone, 
                enrollment_year, 
                course_batch, 
                city, 
                graduation_year
            ))

            student_ids.append(self.cursor.lastrowid)

        self.student_db.commit()
        print(f"✅ Inserted {n} student records into 'students' table")
        return student_ids
