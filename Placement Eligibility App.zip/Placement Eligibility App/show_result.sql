USE student_database;

SHOW TABLES;

SELECT * FROM students LIMIT 20;
SELECT * FROM programming LIMIT 20;
SELECT * FROM soft_skills LIMIT 20;
SELECT * FROM placements LIMIT 20;