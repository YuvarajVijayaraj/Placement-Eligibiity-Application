import random

class SoftSkill:
    def __init__(self, student_db_cursor, student_db):
        self.student_db = student_db
        self.cursor = student_db_cursor

    def create_table(self):
        self.cursor.execute("""
        CREATE TABLE IF NOT EXISTS soft_skills (
            soft_skill_id INT AUTO_INCREMENT PRIMARY KEY,
            student_id INT,
            communication INT,
            teamwork INT,
            presentation INT,
            leadership INT,
            critical_thinking INT,
            interpersonal_skills INT,
            FOREIGN KEY (student_id) REFERENCES students(student_id)
        )
        """)
        self.student_db.commit()
        print("✅ 'soft_skills' table created")

    def insert_data(self, student_ids):
        for student_id in student_ids:
            self.cursor.execute("""
            INSERT INTO soft_skills (student_id, communication, teamwork, presentation, leadership,
            critical_thinking, interpersonal_skills)
            VALUES (%s, %s, %s, %s, %s, %s, %s)
            """, (
                student_id,
                random.randint(60, 100),
                random.randint(60, 100),
                random.randint(60, 100),
                random.randint(60, 100),
                random.randint(60, 100),
                random.randint(60, 100)
            ))
        self.student_db.commit()
        print(f"✅ Inserted soft skills for {len(student_ids)} students")
